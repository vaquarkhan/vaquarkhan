# Processing Twitter's top stories with Apache Spark
## A PoC to learn Spark and its libraries.

[Read the post](http://arjon.es/2014/07/07/processing-twitter-s-top-stories-with-apache-spark-part-1/) and let me know what do you think